// require elemenets
const Alexa = require('ask-sdk-core');
const AWS = require('aws-sdk');
var https = require('https');
var request = require('request');

const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    handle(handlerInput) {
        const speakOutput = 'Hi, welcome to soolis. We are an advanced digital marketing firm and fitness equipment data provider. We are here 24-7 to answer all your questions. What brings you here, marketing or fitness equipment information?';
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

//My custom lambda function execution handler
const StartedLambdaExecuteHandler = {
  canHandle(handlerInput) {
    const { request } = handlerInput.requestEnvelope;
    return request.type === 'IntentRequest'
      && request.intent.name === 'ContactSales';
  },
  async handle(handlerInput) {
    const currentIntent = handlerInput.requestEnvelope.request.intent;
    const requestAttributes = handlerInput.attributesManager.getRequestAttributes();
    
    const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
   
     if (sessionAttributes.firstname) {
      return handlerInput.responseBuilder
        .speak(`Welcome Back ${sessionAttributes.firstname}, Seems like You are already came here before.`)
        .getResponse();
    } else{
        const firstname = currentIntent.slots.firstname.value;
        const lastname = currentIntent.slots.lastname.value;
        sessionAttributes.firstname = firstname;
        handlerInput.attributesManager.setSessionAttributes(sessionAttributes);
        // save information into database through api
        request.post({
                "headers": { "content-type": "application/json" },
                "url": "https://testingwebsitedesign.com/wadvisors/sellers/getcomv3",
                "body": JSON.stringify({
                    "firstname": firstname,
                    "lastname": lastname
                })
            }, (error, response, body) => {
                if(error) {
                    return console.dir(error);
                }
                //var resp = JSON.parse(body);
                
            });
        // end response
        const speechText = `I saved the your name ${firstname} in our records.`;
        return handlerInput.responseBuilder
          .speak(speechText)
          .getResponse();
    }
      
  }
};


function httpGet() {
  return new Promise(((resolve, reject) => {
    var options = {
        host: 'testingwebsitedesign.com',
        port: 443,
        path: '/wadvisors/sellers/getcom',
        method: 'GET',
    };
    
    const request = https.request(options, (response) => {
      response.setEncoding('utf8');
      let returnData = '';

      response.on('data', (chunk) => {
        returnData += chunk;
      });

      response.on('end', () => {
        resolve(JSON.parse(returnData));
      });

      response.on('error', (error) => {
        reject(error);
      });
    });
    request.end();
  }));
}

const GetJokeHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && request.intent.name === 'ContentMarkeing';
  },
  async handle(handlerInput) {
    const response = await httpGet();
    // handle post request
    /*request.post({
        "headers": { "content-type": "application/json" },
        "url": "https://testingwebsitedesign.com/wadvisors/sellers/getcomv3",
        "body": JSON.stringify({
            "firstname": "Tim",
            "lastname": "Sebold"
        })
    }, (error, response, body) => {
        if(error) {
            return console.dir(error);
        }
        var resp = JSON.parse(body);
         return handlerInput.responseBuilder
            .speak("Okay. Here is what I got back from my request. " + resp)
            .getResponse();
        //console.dir(JSON.parse(body));
    });*/
    
    // handling get request to get data.
    /*var options = {
      method: 'GET',
      url: 'https://testingwebsitedesign.com/wadvisors/sellers/getcomv2',
      qs: {id: '3'},
      headers: {accept: 'application/json'}
    };
    
    request(options, function (error, response, body) {
      if (error) throw new Error(error);
      var res = JSON.parse(body);
       return handlerInput.responseBuilder
            .speak("Okay. Here is what I got back from my request. " + res[0].companytype)
            .getResponse();
    });
   */
    
    return handlerInput.responseBuilder
            .speak("Okay. Here is what I got back from my request. " + response[0].companytype)
            .getResponse();
   
  },
};

const FitnessEquipmentIntentHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && request.intent.name === 'FitnessEquipment';
  },
  handle(handlerInput) {
    const speakOutput = 'We do not sell any fitness equipment. We provide detailed product information. If you are on the phone switch to the chatbot to see your fitness equipment inquiries. You can request "show me" new Precor Resolute Strength, Freemotion Genesis equipment, new Life Fitness treadmills, used Precor ellipticals, and much more. What specific product can we show you?';

    return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
   
  },
};

const EmailMarketingIntentHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && request.intent.name === 'EmailMarketing';
  },
  handle(handlerInput) {
    const speakOutput = 'We have a comprehensive email system It will take all the development out of your hands, you just need to provide the concept. We do NOT provide email lists. That will be up to you. The cost is $500 to set up and $300 a month';

    return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
   
  },
};

const SoolisMarketsIntentHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && request.intent.name === 'SoolisMarkets';
  },
  handle(handlerInput) {
    const speakOutput = 'We can create chatbots for any business.';
    return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
   
  },
};


const SoolisChatbotFeeIntentHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && request.intent.name === 'SoolisChatbotFee';
  },
  handle(handlerInput) {
    const speakOutput = 'Chatbots have a develop fee and a monthly fee. The develop fee will start at $2,500 and will go up depending on the amount of integrations. The monthly fee starts at $399 and will go up depending on your monthly traffic';
    return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
   
  },
};


const SoolisChatbotIntentHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && request.intent.name === 'SoolisChatbot';
  },
  handle(handlerInput) {
    const speakOutput = 'Here are a few benefits of chatbots. They will communicate with your customers and prospects with 24/7 customer service via phone, website or voice automation from Google & Alexa. They are there when you can not be. They help cut down on operational costs. They offer progressive avenues for customer service, marketing and sales. They can showcase new products and services. For more information say transfer to customer service or say or type contact sales';
    return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
   
  },
};

const SoolisMarketingIntentHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && request.intent.name === 'SoolisMarketing';
  },
  handle(handlerInput) {
    const speakOutput = 'Formed in 2009, soOlis has evolved from a fitness equipment database website to one of the most advanced digital marketing company in the country. Over the past 3 years, soOlis has focus primarily on chatbots, voice and artificial intelligence while still supporting the basic marketing strategies of content, email and pay per click.';
    return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
   
  },
};

const ContentManagementIntentHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && request.intent.name === 'ContentManagement';
  },
  handle(handlerInput) {
    const speakOutput = 'With content marketing a business can increases visibility of your brand. Increase their S.E.O. presence. Develops lasting relationships with your audience. Improves brand awareness and recognition. Creates loyalty and trust, with both your current customers and prospects. Helps you to build authority and credibility. Positions your business as an expert in your industry. For more information on Content Marketing just type or ask to contact sales.';
    return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
   
  },
};


const FitnessEquipmentPortalIntentHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && request.intent.name === 'FitnessEquipmentPortal';
  },
  handle(handlerInput) {
    const speakOutput = 'The Fitness Equipment Management Portal, or FEMP, was designed to provide individuals and companies access to almost all the home and commercial fitness equipment information. We have roughly 40,000 products. Individuals can research and compare different fitness manufactures side by side. Companies like fitness distributors and publications can utilize the information for thier specific websites. The equipment is constantly being updated to rovide the latest information from different manufcatures. The fitness information is perfect for distributors who do not have time to update their website and publications for additional content and additional advertising opportunities. To access the FEMP, just ask about fitness equipment information like show me Life Fitness treadmills.';
    return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
   
  },
};

const EquipmentCompaniesIntentHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && request.intent.name === 'EquipmentCompanies';
  },
  handle(handlerInput) {
    const speakOutput = 'We work with Level Red Boxing, Fitness U, Club Industry, Onelife Fitness, energyFit, FMI International, California Family Fitness and more. For more information, say or type contact sales';
    return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
   
  },
};

const SoolisMarketingServicesIntentHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && request.intent.name === 'SoolisMarketingServices';
  },
  handle(handlerInput) {
    const speakOutput = 'We specialize in chatbots, AI Voice, Content Marketing, Email and Pay Per Click. What specific marketing solutions can we help you with?';
    return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
   
  },
};



const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'You can say hello to me! How can I help?';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};
const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = 'Goodbye!';
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse();
    }
};

// The intent reflector is used for interaction model testing and debugging.
// It will simply repeat the intent the user said. You can create custom handlers
// for your intents by defining them above, then also adding them to the request
// handler chain below.
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speakOutput = `You just triggered ${intentName}`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};

// Generic error handling to capture any syntax or routing errors. If you receive an error
// stating the request handler chain is not found, you have not implemented a handler for
// the intent being invoked or included it in the skill builder below.
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        console.log(`~~~~ Error handled: ${error.stack}`);
        const speakOutput = `Sorry, I had trouble doing what you asked. Please try again.`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};



// The SkillBuilder acts as the entry point for your skill, routing all request and response
// payloads to the handlers above. Make sure any new handlers or interceptors you've
// defined are included below. The order matters - they're processed top to bottom.
exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        StartedLambdaExecuteHandler,
        HelpIntentHandler,
        GetJokeHandler,
        FitnessEquipmentIntentHandler,
        EmailMarketingIntentHandler,
        SoolisMarketsIntentHandler,
        SoolisChatbotFeeIntentHandler,
        SoolisChatbotIntentHandler,
        SoolisMarketingIntentHandler,
        ContentManagementIntentHandler,
        FitnessEquipmentPortalIntentHandler,
        EquipmentCompaniesIntentHandler,
        SoolisMarketingServicesIntentHandler,
        CancelAndStopIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler, // make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers
    )
    .addErrorHandlers(
        ErrorHandler,
    )
    .lambda();


